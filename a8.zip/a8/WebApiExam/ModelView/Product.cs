﻿


using System.ComponentModel.DataAnnotations;

namespace modelview
{
    public class Product
    {
        [Key]

        public int productid { get; set; }
        [Required]
        public string name { get; set; }
        public string description { get; set; }
        public int price { get; set; }
        public int quantity { get; set; }

        public bool isactive { get; set; }
        public DateTime createdon { get; set; } = DateTime.Now;
        public DateTime modifiedon { get; set; } = DateTime.Now;

     
    }
}
