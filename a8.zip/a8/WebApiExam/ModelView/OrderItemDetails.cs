﻿using ModelView;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelView
{
    public class OrderItemDetails
    {
        [Key]
        public int OrderItemId { get; set; }
        
        public int Quantity { get; set; }
        
        public double Price { get; set; }
        
        public bool IsActive { get; set; }


        public int OrderId { get; set; }
        [ForeignKey("OrderId")]
        
        public OrderDetails order { get; set; }

        public int ProductId { get; set; }
       
    }
}

     
     
     
     
     
     