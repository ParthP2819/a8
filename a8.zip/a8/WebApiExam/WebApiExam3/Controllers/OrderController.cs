﻿using DataAccess.Data;
using DataAccess.Repository;
using DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModelView;
using ModelView.ViewModel;

namespace WebApiExam3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<IdentityUser> _userManager;
        public OrderController(IUnitOfWork unitOfWork, UserManager<IdentityUser> userManager)
        {
            _unitOfWork = unitOfWork;
            _userManager = userManager;
        }

       

      

        [HttpGet]
        [Route("ProductList")]
        public async Task<IActionResult> PostProductItem()
        {
            var data = _unitOfWork.Product.GetAll();
            var productlist = data.Select(x => new { x.productid,x.name,x.quantity,x.price });

            return Ok(productlist);
        }




        
        [HttpPost]
        [Route("SelectProduct")]
        public async Task<IActionResult> PostOrder(RequestOrderitem requestOrderitem )
        {

            var userdata = await _userManager.FindByNameAsync(requestOrderitem.username);
            var totalamount = requestOrderitem.Price * requestOrderitem.Quantity;
            if (userdata == null)
            {
                return BadRequest("You have To Login First");
            }
            else
            {
                var check = _unitOfWork.order.GetFirstorDefault(x => x.CustomerName == requestOrderitem.username);
                var orderdata = new OrderDetails();
                if (check==null)
                {


                    orderdata.CustomerName = userdata.UserName;
                    orderdata.CustomerEmail = userdata.Email;
                    orderdata.CustomerContactNo = userdata.PhoneNumber;
                    orderdata.StatusType = StatusType.Open.ToString();
                    orderdata.IsActive = true;
                    orderdata.DisountAmount= 0;
                    orderdata.Note = "";
                    orderdata.TotalAmount= totalamount;

                    
                    _unitOfWork.order.Add(orderdata);
                    _unitOfWork.Save();

                    var orderitemdata = new OrderItemDetails()
                    {
                        Quantity = requestOrderitem.Quantity,
                        OrderId = orderdata.OrderId,
                        ProductId = requestOrderitem.productId,
                    };

                    _unitOfWork.orderitem.Add(orderitemdata);
                    _unitOfWork.Save();
                }
                else 
                {
                    var  orderid = _unitOfWork.order.GetFirstorDefault(x => x.CustomerName == requestOrderitem.username);
                    var orderitemdata = new OrderItemDetails()
                    {
                        Quantity = requestOrderitem.Quantity,
                        OrderId = orderid.OrderId,
                        ProductId = requestOrderitem.productId,
                    };

                 
                  

                    _unitOfWork.orderitem.Add(orderitemdata);
                    _unitOfWork.Save();
                }
              
               
            }


            return Ok(new ResponseOrderItem() { Message="Add Item Successfully...."});
        }


        [Authorize]
        [HttpGet]
        [Route("GetOrder")]
        public async Task<IActionResult> GetOrder(string statusType)
        {
      
            
            var data= _unitOfWork.order.GetAll();
            var filterdata=data.Select(x => new { x.OrderId,x.Note,x.StatusType,x.CreatedOn});
            return Ok(filterdata);
        }



    }

   
}
