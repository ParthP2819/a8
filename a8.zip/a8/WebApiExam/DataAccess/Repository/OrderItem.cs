﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class OrderItem : Repository<OrderItemDetails>, IOrderItem
    {
        private readonly ApplicationDbContext _db;
        public OrderItem(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public void Update(OrderItemDetails item)
        {
           _db.Update(item);
        }
    }
}
