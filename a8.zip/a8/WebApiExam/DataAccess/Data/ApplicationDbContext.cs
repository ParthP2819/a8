﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ModelView;
using modelview;

namespace DataAccess.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
      
        public ApplicationDbContext(DbContextOptions options ) : base(options) 
        {
            
        }
        public DbSet<OrderDetails> orders { get; set; }
        public DbSet<OrderItemDetails> orderItems { get; set; }
       
        public DbSet<Product> products { get; set; }

    }
}
