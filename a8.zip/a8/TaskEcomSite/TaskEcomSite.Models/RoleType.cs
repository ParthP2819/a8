﻿namespace TaskEcomSite.Models
{
    public enum RoleType
    {
        Admin,
        SuperAdmin,
        Dealler
    }
    public enum Status
    {
        Approve,
        Pending,
        Reject,
        Block
    }
}
