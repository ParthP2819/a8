﻿namespace WebApi_s.Data
{
    public class ApplicationDbContext
    {
    }
}
