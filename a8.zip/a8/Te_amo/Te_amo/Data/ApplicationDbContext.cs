﻿namespace Te_amo.Data
{
    public class ApplicationDbContext
    {
    }
}
